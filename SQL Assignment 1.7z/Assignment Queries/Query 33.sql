SELECT ename
FROM emp
WHERE ename LIKE '__L%';