SELECT job,ROUND(Avg(sal),2) AS 'Average Salary'
FROM emp
WHERE job='Manager'
GROUP BY job