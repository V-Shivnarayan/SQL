SELECT GETDATE() AS 'Shivnarayan Vaidyanathan'
