SELECT ename,sal
FROM emp
WHERE sal=800 OR sal=950 OR sal=3000 OR sal=5000
ORDER BY sal