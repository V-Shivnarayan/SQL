SELECT E.deptno,D.dname,SUM(SAL) AS 'Total Salary'
FROM emp E,Dept D
WHERE E.deptno=D.deptno
GROUP BY E.deptno,D.dname;