SELECT ename,sal
FROM emp
WHERE sal>=500 AND sal<=1000