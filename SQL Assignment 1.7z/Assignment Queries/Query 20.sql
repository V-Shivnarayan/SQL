SELECT ename,sal
FROM emp
WHERE sal < 3500