SELECT ename,MAX(COMM) AS 'Highest Commission'
FROM emp
GROUP BY ename