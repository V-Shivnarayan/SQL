SELECT *
FROM emp
WHERE job LIKE 'Manager'