SELECT ename,job
FROM emp
WHERE job LIKE 'President'