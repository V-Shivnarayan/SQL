Create function Func()      
returns table       
as      
return(select * from salesorders)

SELECT * FROM Func() WHERE order_date 
	BETWEEN '2016-01-01' AND ('2016-01-02')

SELECT *
FROM Func();