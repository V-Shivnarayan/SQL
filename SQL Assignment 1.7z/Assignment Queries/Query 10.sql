SELECT ename
FROM emp
WHERE LEN(ename)=5