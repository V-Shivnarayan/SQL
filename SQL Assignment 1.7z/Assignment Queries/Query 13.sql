SELECT empno,ename
FROM emp
WHERE ename LIKE 'james'