SELECT ename,Min(sal) AS 'Lowest Salary'
FROM emp
WHERE deptno=10
GROUP BY ename
