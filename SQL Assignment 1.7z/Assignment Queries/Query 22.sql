SELECT ename,sal AS 'Monthly Salary',sal*12 AS 'Annual Salary'
FROM emp
