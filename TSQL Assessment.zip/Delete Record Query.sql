CREATE TRIGGER customer_audits_log
       ON customer_audits
AFTER DELETE
AS
BEGIN
       SET NOCOUNT ON;
 
       DECLARE @CustomerId INT
 
       SELECT @CustomerId = DELETED.customer_id       
       FROM DELETED
 
       INSERT INTO customer_log
       VALUES(@CustomerId, 'Deleted')
END

