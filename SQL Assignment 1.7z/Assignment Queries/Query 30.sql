SELECT job,MAX(sal) AS 'Highest Salary'
FROM emp
WHERE job='Analyst'
GROUP BY job