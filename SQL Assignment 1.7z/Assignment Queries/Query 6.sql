SELECT ename,sal
FROM emp
WHERE sal<=1000 OR sal>=2500
ORDER BY sal