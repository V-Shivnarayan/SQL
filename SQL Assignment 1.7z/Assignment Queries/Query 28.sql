SELECT job,COUNT(*) AS 'No Of Person'
FROM emp
GROUP BY job;