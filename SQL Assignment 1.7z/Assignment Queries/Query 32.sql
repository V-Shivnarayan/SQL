SELECT COUNT(deptno) AS 'No Of Departments'
FROM dept;