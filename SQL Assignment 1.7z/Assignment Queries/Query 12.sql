SELECT ename
FROM emp
WHERE ename LIKE '%A%'
