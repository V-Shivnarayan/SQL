SELECT deptno,ename,job
FROM emp
WHERE job='CLERK' OR job='MANAGER'