SELECT job,SUM(sal) AS 'Total Salary'
FROM emp
GROUP BY deptno,job
HAVING Avg(sal)<(SELECT Avg(sal) FROM emp);
