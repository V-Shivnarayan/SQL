SELECT ename
FROM emp
WHERE ename LIKE  'C%K'