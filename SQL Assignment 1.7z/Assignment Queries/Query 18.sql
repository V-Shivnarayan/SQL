SELECT ename,hiredate
FROM emp
WHERE HIREDATE < ('01/APR/1981')