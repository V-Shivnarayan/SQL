SELECT DISTINCT deptno,ename,job
FROM emp
WHERE job='CLERK'