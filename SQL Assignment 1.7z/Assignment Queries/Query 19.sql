SELECT ename,sal
FROM emp
WHERE ename IN ('King','Blake','Ford','Smith')