SELECT ename,sal
FROM emp
WHERE ename LIKE 'king'