SELECT ename,sal AS 'Monthly Salary',sal+(sal*20)/100 AS 'Hike',(sal+(sal*20)/100)*12 AS 'Annual Salary' 
FROM emp
WHERE ename LIKE 'Ford'
